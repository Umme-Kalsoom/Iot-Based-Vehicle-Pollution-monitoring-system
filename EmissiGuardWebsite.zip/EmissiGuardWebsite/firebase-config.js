// For Firebase JS SDK v7.20.0 and later, measurementId is optional
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAXdtY9e6jmmtrtFCpaDEO3lUpPpBax284",
  authDomain: "emssi-gaurd.firebaseapp.com",
  databaseURL: "https://emssi-gaurd-default-rtdb.firebaseio.com",
  projectId: "emssi-gaurd",
  storageBucket: "emssi-gaurd.appspot.com",
  messagingSenderId: "662054717926",
  appId: "1:662054717926:web:0c9d327bc5ff47a87b2e27",
  measurementId: "G-EZC29WWFDR"
};

  // Initialize Firebase
  const app = firebase.initializeApp(firebaseConfig);
  const auth = firebase.auth();
